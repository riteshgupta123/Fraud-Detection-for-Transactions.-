
# Fraud Detection for Transactions

## Project Overview
This project detects fraudulent credit card transactions using machine learning. It helps financial institutions identify suspicious activity in real-time.

## Dataset
Dataset used: [Credit Card Fraud Detection - Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)
- Features: V1–V28 (PCA components), `Amount`, `Time`
- Target: `Class` (0 = legitimate, 1 = fraud)

## Steps in the Project
1. Data Loading & Exploration
2. Data Preprocessing (scaling `Amount` and `Time`)
3. Handling Class Imbalance (SMOTE)
4. Model Training (Random Forest Classifier)
5. Model Evaluation (Precision, Recall, F1-score, ROC-AUC)
6. Visualizations (Confusion Matrix, ROC Curve)

## Technologies Used
- Python
- Pandas, NumPy
- Scikit-learn, Imbalanced-learn
- Matplotlib, Seaborn

## How to Run
1. Download dataset `creditcard.csv` from Kaggle.
2. Place it in the same folder as the notebook.
3. Run `Fraud_Detection_for_Transactions.ipynb` in Jupyter Notebook or VS Code.
4. View the output visualizations and evaluation metrics.

## Output
- Classification report with precision, recall, and F1-score
- Confusion matrix and ROC curve
